def test():
    print("hello")


